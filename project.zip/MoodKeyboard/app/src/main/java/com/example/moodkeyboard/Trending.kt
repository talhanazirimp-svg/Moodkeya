package com.example.moodkeyboard

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

data class Song(val title: String, val artist: String)

/**
 * Trending Reels songs. Works like a keyboard language pack:
 * built-in list first, then a newer list downloaded from TRENDING_URL replaces it and is cached on the phone.
 */
object Trending {
    /** Put trending.json in your own GitHub repo (or any web host) and paste its raw link here. */
    const val TRENDING_URL = "https://raw.githubusercontent.com/talhanazirimp-svg/Moodkey/main/trending.json"

    private val sahiba = Song("Sahiba", "Aditya Rikhari")
    private val gehra = Song("Gehra Hua", "Shashwat Sachdev Arijit Singh")
    private val dhur = Song("Dhurandhar Title Track", "Shashwat Sachdev")
    private val daaru = Song("Thodi Si Daaru", "AP Dhillon Shreya Ghoshal")
    private val raanjhan = Song("Raanjhan", "Vishal Mishra")
    private val raat = Song("Aaj Ki Raat", "Madhubanti Bagchi")
    private val aae = Song("Aae Ajnabee", "Aditya Rikhari Kutle Khan")
    private val lambiyan = Song("Raataan Lambiyan", "Jubin Nautiyal")
    private val jaana = Song("Jaana Samjho Na", "Aditya Rikhari")
    private val faasle = Song("Faasle", "Aditya Rikhari")
    private val tujahaan = Song("Tu Jahaan", "Aditya Rikhari")
    private val perfect = Song("Perfect", "Guru Randhawa")

    var version = "built-in Hindi (Oct 2026)"; private set
    var top: List<Song> = listOf(sahiba, gehra, dhur, daaru, raanjhan, raat, aae, lambiyan, jaana); private set
    private var byMood: Map<Mood, List<Song>> = mapOf(
        Mood.HAPPY to listOf(daaru, perfect, raat),
        Mood.SAD to listOf(raanjhan, jaana, faasle),
        Mood.ROMANTIC to listOf(sahiba, lambiyan, tujahaan),
        Mood.ANGRY to listOf(dhur, raat, perfect),
        Mood.EXCITED to listOf(raat, dhur, perfect),
        Mood.STRESSED to listOf(aae, gehra, faasle),
        Mood.CHILL to listOf(aae, gehra, sahiba)
    )

    fun forMood(m: Mood?): List<Song> = if (m == null) top else (byMood[m]?.takeIf { it.isNotEmpty() } ?: top)

    private fun file(ctx: Context) = File(ctx.filesDir, "trending.json")

    /** Call once when the keyboard starts: loads the last downloaded list, if any. */
    fun loadCached(ctx: Context) {
        val f = file(ctx)
        if (f.exists()) parse(f.readText())
    }

    /** Downloads the newest list. Runs on its own thread; onDone gets a short status message. */
    fun update(ctx: Context, onDone: (String) -> Unit) {
        Thread {
            val msg = try {
                val c = URL(TRENDING_URL).openConnection() as HttpURLConnection
                c.connectTimeout = 6000; c.readTimeout = 6000
                val text = c.inputStream.bufferedReader().readText()
                if (parse(text)) {
                    file(ctx).writeText(text)
                    ctx.getSharedPreferences("trend", Context.MODE_PRIVATE).edit()
                        .putLong("last", System.currentTimeMillis()).apply()
                    "Trending updated: $version"
                } else "Bad trending file"
            } catch (e: Exception) { "Couldn't update (offline or URL not set)" }
            onDone(msg)
        }.start()
    }

    /** Checks at most once a day, silently. */
    fun autoUpdateIfStale(ctx: Context) {
        val last = ctx.getSharedPreferences("trend", Context.MODE_PRIVATE).getLong("last", 0)
        if (System.currentTimeMillis() - last > 24L * 3600 * 1000) update(ctx) {}
    }

    private fun parse(json: String): Boolean = try {
        val root = JSONObject(json)
        fun songs(a: org.json.JSONArray) = (0 until a.length()).map {
            val o = a.getJSONObject(it); Song(o.getString("title"), o.getString("artist"))
        }
        val newTop = songs(root.getJSONArray("top"))
        val moods = root.getJSONObject("moods")
        val newMap = Mood.values().associateWith { m ->
            if (moods.has(m.name)) songs(moods.getJSONArray(m.name)) else emptyList()
        }
        if (newTop.isEmpty()) false else {
            version = root.optString("version", "downloaded")
            top = newTop; byMood = newMap; true
        }
    } catch (e: Exception) { false }
}
