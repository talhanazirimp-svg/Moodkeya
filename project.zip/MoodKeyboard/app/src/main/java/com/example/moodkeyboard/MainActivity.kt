package com.example.moodkeyboard

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Trending.loadCached(this)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        col.addView(TextView(this).apply { text = "MoodKeyboard\nTrending Reels songs that follow your vibe."; textSize = 18f })
        val ver = TextView(this).apply { text = "Trending list: ${Trending.version}" }
        col.addView(Button(this).apply {
            text = "1. Enable keyboard"
            setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        })
        col.addView(Button(this).apply {
            text = "2. Switch to MoodKeyboard"
            setOnClickListener { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() }
        })
        col.addView(Button(this).apply {
            text = "3. Download latest trending"
            setOnClickListener {
                Trending.update(this@MainActivity) { msg ->
                    runOnUiThread { ver.text = "Trending list: ${Trending.version}"; Toast.makeText(this@MainActivity, msg, Toast.LENGTH_LONG).show() }
                }
            }
        })
        col.addView(ver)
        col.addView(EditText(this).apply { hint = "Test here: type anything" })
        setContentView(col)
    }
}
