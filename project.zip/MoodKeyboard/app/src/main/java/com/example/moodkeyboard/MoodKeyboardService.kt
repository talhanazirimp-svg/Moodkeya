package com.example.moodkeyboard

import android.content.ClipboardManager
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.inputmethodservice.InputMethodService
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.abs

/**
 * Samsung-style keyboard: number row, rounded keys, no vibration, no key sounds, word suggestions,
 * long-press accents, space-bar cursor swipe, symbols 1/2 and 2/2, clipboard paste, one-handed mode.
 * On top of that it judges the vibe of what you type (on-device) and plays a trending song preview.
 */
class MoodKeyboardService : InputMethodService() {

    private val main = Handler(Looper.getMainLooper())
    private var player: MediaPlayer? = null
    private var playToken = 0
    private var pending: Runnable? = null

    private var shiftState = 0            // 0 off, 1 once, 2 caps lock
    private var lastShiftTap = 0L
    private var symPage = 0               // 0 letters, 1 symbols 1/2, 2 symbols 2/2
    private var emojiMode = false
    private var oneHand = 0               // 0 normal, 1 left, 2 right
    private var secure = false
    private var auto = true
    private var mood: Mood? = null
    private var songIdx = 0
    private var song: Song? = null
    private var link: String? = null
    private var emojiSet = listOf("😂", "❤️", "😍", "😭", "🔥", "👍", "🙏", "😊", "🥰", "😘")
    private val buffer = StringBuilder()   // recent typed words, memory only, never saved
    private var altPopup: PopupWindow? = null

    private lateinit var rootView: LinearLayout
    private lateinit var strip: TextView
    private lateinit var playBtn: Button
    private lateinit var autoBtn: Button
    private lateinit var suggestBar: LinearLayout
    private lateinit var numberRow: LinearLayout
    private lateinit var keysArea: LinearLayout
    private lateinit var emojiPanel: ScrollView
    private lateinit var symBtn: Button
    private lateinit var emojiToggle: Button
    private var shiftBtn: Button? = null
    private val letterKeys = mutableListOf<Button>()

    private var cBg = 0; private var cKey = 0; private var cSpecial = 0; private var cText = 0
    private val cAccent = Color.parseColor("#4A6CF7")

    private val moodEmojis = mapOf(
        Mood.HAPPY to listOf("😄", "😂", "🥳", "😁", "😊", "🙌"),
        Mood.SAD to listOf("😢", "😭", "💔", "🥺", "😞", "🫂"),
        Mood.ROMANTIC to listOf("😍", "🥰", "😘", "❤️", "💕", "😏"),
        Mood.ANGRY to listOf("😡", "🤬", "😤", "💢", "🙄", "😒"),
        Mood.EXCITED to listOf("🎉", "🤩", "🔥", "🥳", "🚀", "💃"),
        Mood.STRESSED to listOf("😰", "😩", "😫", "😬", "🙏", "☕"),
        Mood.CHILL to listOf("😌", "☕", "😴", "🌧️", "🎧", "🍿")
    )
    private val allEmojis: List<String> = splitEmojis(
        "😀😃😄😁😆😅😂🤣😊😇🙂😉😍🥰😘😗😋😛😜🤪😎🤩🥳😏😒😞😔😟😕🙁😣😖😫😩🥺😢😭😤😠😡🤬🤯😳🥵🥶😱😰😥😓🤗🤔🤭🤫🙄😬😴🤤😷🤒" +
        "👍👎👏🙌🙏💪👋🤝✌️🤞👌🤙❤️🧡💛💚💙💜🖤💔💕💖💯🔥✨🎉🎊🎶🎵🎧☕🍕🍔🍟🍿🎂🌹🌧️☀️🌙⭐🚀💃🕺"
    )
    private val altMap = mapOf(
        'a' to "àáâäæãåā", 'e' to "èéêëēėę", 'i' to "îïíīįì", 'o' to "ôöòóœøōõ", 'u' to "ûüùúū",
        'c' to "çćč", 'n' to "ñń", 's' to "ßśš", 'y' to "ÿý", 'z' to "žźż", 'l' to "ł", 'd' to "đ",
        '.' to "…!?:;'\"-", ',' to "&@#%"
    )
    private val words = ("the and you that for with this have not are but what your all can was one our out day get has him his how " +
        "new now see way who did let say she too use hello hi thanks thank please sorry good morning night evening love miss call " +
        "tomorrow today tonight where when why will would could should really maybe okay yes no bro bhai kya haan nahi theek accha " +
        "kaise kaisa hai hain tum main mujhe tumhe pyaar dost kab kahan abhi baad phir aaj kal chalo yaar bahut mast sach jaldi " +
        "birthday party dinner lunch coming reached waiting busy free meeting office home friend family happy sad angry tired sleep " +
        "eating going doing thinking message photo video song music reel congratulations welcome awesome amazing beautiful " +
        "because before after about think know want need come back tell give take make look right sure just also very much").split(" ").distinct()

    private fun splitEmojis(str: String): List<String> {
        val out = mutableListOf<String>()
        var i = 0
        while (i < str.length) {
            val cp = str.codePointAt(i)
            var len = Character.charCount(cp)
            while (i + len < str.length && (str[i + len] == '\uFE0F' || str[i + len] == '\u200D')) len++
            out.add(str.substring(i, i + len)); i += len
        }
        return out
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate() {
        super.onCreate()
        Trending.loadCached(this)
        Trending.autoUpdateIfStale(this)
    }

    override fun onCreateInputView(): View {
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        cBg = Color.parseColor(if (night) "#1B1B1D" else "#E6E7EB")
        cKey = Color.parseColor(if (night) "#3A3A3F" else "#FFFFFF")
        cSpecial = Color.parseColor(if (night) "#2A2A2E" else "#CFD1D8")
        cText = Color.parseColor(if (night) "#F2F2F2" else "#111111")

        rootView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(cBg)
        }
        applyOneHand()

        strip = TextView(this).apply {
            text = "🎧 Type and a trending song will follow your vibe"
            textSize = 13f
            setTextColor(cText)
            background = shape(cKey)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnLongClickListener { openYouTube(); true }
            isHapticFeedbackEnabled = false
        }
        rootView.addView(strip, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })

        // toolbar
        val tools = row()
        playBtn = key("▶", true, size = 15f) { togglePlay() }
        autoBtn = key("Auto ✓", true, size = 12f) { auto = !auto; autoBtn.text = if (auto) "Auto ✓" else "Auto ✗" }
        tools.addView(playBtn, weight(1f, 38))
        tools.addView(key("⏭", true, size = 15f) { songIdx++; choose(true) }, weight(1f, 38))
        tools.addView(autoBtn, weight(1.5f, 38))
        tools.addView(key("📤", true, size = 15f) { sendClip() }, weight(1f, 38))
        tools.addView(key("📋", true, size = 15f) { pasteClipboard() }, weight(1f, 38))
        tools.addView(key("⇆", true, size = 15f) { oneHand = (oneHand + 1) % 3; applyOneHand() }, weight(1f, 38))
        tools.addView(key("🌐", true, size = 15f) { picker() }, weight(1f, 38))
        rootView.addView(tools)

        // suggestions (words while typing, emojis otherwise)
        suggestBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        rootView.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(suggestBar) })
        updateSuggestions()

        numberRow = row()
        "1234567890".forEach { c -> numberRow.addView(key(c.toString()) { type(c.toString()) }, weight(1f)) }
        rootView.addView(numberRow)

        keysArea = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        buildKeyRows()
        rootView.addView(keysArea)

        emojiPanel = ScrollView(this).apply { visibility = View.GONE }
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        allEmojis.chunked(8).forEach { chunk ->
            val r = row()
            chunk.forEach { e -> r.addView(key(e) { type(e) }.apply { textSize = 22f }, weight(1f)) }
            repeat(8 - chunk.size) { r.addView(View(this), weight(1f)) }
            grid.addView(r)
        }
        emojiPanel.addView(grid)
        rootView.addView(emojiPanel, LinearLayout.LayoutParams(-1, dp(200)))

        val bottom = row()
        symBtn = key("?123", true) { symPage = if (symPage == 0) 1 else 0; symBtn.text = if (symPage == 0) "?123" else "ABC"; buildKeyRows() }
        emojiToggle = key("😊", true) { toggleEmojiPanel() }
        bottom.addView(symBtn, weight(1.4f))
        bottom.addView(emojiToggle, weight(1f))
        bottom.addView(key(",", alts = altMap[',']) { type(",") }, weight(1f))
        bottom.addView(spaceKey(), weight(4f))
        bottom.addView(key(".", alts = altMap['.']) { type(".") }, weight(1f))
        bottom.addView(key("↵", false, true) { doEnter() }, weight(1.5f))
        rootView.addView(bottom)
        return rootView
    }

    private fun applyOneHand() {
        val shrink = (resources.displayMetrics.widthPixels * 0.22).toInt()
        rootView.setPadding(dp(3) + if (oneHand == 2) shrink else 0, dp(4), dp(3) + if (oneHand == 1) shrink else 0, dp(4))
    }

    private fun toggleEmojiPanel() {
        emojiMode = !emojiMode
        emojiPanel.visibility = if (emojiMode) View.VISIBLE else View.GONE
        keysArea.visibility = if (emojiMode) View.GONE else View.VISIBLE
        numberRow.visibility = if (emojiMode) View.GONE else View.VISIBLE
        emojiToggle.text = if (emojiMode) "ABC" else "😊"
    }

    private fun buildKeyRows() {
        keysArea.removeAllViews(); letterKeys.clear(); shiftBtn = null
        val rows = when (symPage) {
            0 -> listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")
            1 -> listOf("@#\$_&-+()/", "*\"':;!?%", "~|•√÷×")
            else -> listOf("[]{}<>^`~\\", "=±€£¥₹¢°•", "|√π¶§©®")
        }
        rows.forEachIndexed { idx, chars ->
            val r = row()
            if (idx == 1 && symPage == 0) r.addView(View(this), weight(0.5f))
            if (idx == 2) {
                if (symPage > 0) r.addView(key(if (symPage == 1) "2/2" else "1/2", true) { symPage = if (symPage == 1) 2 else 1; buildKeyRows() }, weight(1.5f))
                else { shiftBtn = key(shiftLabel(), true) { onShift() }; r.addView(shiftBtn, weight(1.5f)) }
            }
            chars.forEach { c ->
                val b = key(c.toString(), alts = if (symPage == 0) altMap[c] else null) { onChar(c) }
                if (symPage == 0) letterKeys.add(b)
                r.addView(b, weight(1f))
            }
            if (idx == 2) r.addView(backspaceKey(), weight(1.5f))
            if (idx == 1 && symPage == 0) r.addView(View(this), weight(0.5f))
            keysArea.addView(r)
        }
        refreshCase()
    }

    // ---- keys ---------------------------------------------------------------
    private fun onChar(c: Char) {
        val out = if (symPage == 0 && shiftState != 0) c.uppercaseChar().toString() else c.toString()
        type(out)
        if (shiftState == 1) { shiftState = 0; refreshCase() }
    }

    private fun onShift() {
        val now = SystemClock.uptimeMillis()
        shiftState = when {
            shiftState == 2 -> 0
            now - lastShiftTap < 350 -> 2     // double tap = caps lock
            shiftState == 1 -> 0
            else -> 1
        }
        lastShiftTap = now
        refreshCase()
    }

    private fun shiftLabel() = when (shiftState) { 0 -> "⇧"; 1 -> "⬆"; else -> "⇪" }

    private fun refreshCase() {
        letterKeys.forEach { it.text = if (shiftState != 0) it.text.toString().uppercase() else it.text.toString().lowercase() }
        shiftBtn?.text = shiftLabel()
    }

    private fun backspaceKey(): Button {
        val b = key("⌫", true) {}
        val repeat = object : Runnable { override fun run() { deleteOne(); main.postDelayed(this, 45) } }
        b.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { v.isPressed = true; deleteOne(); main.postDelayed(repeat, 400) }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { v.isPressed = false; main.removeCallbacks(repeat) }
            }
            true
        }
        return b
    }

    /** Space bar: tap = space, slide left/right = move cursor, long-press = switch keyboard. */
    private fun spaceKey(): Button {
        val b = key("MoodKeyboard") {}
        b.setTextColor(Color.parseColor("#8A8D96")); b.textSize = 13f
        var lastX = 0f; var moved = false; var longPressed = false
        val longPress = Runnable { longPressed = true; picker() }
        b.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { v.isPressed = true; lastX = e.x; moved = false; longPressed = false; main.postDelayed(longPress, 700) }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.x - lastX
                    if (abs(dx) > dp(14)) {
                        moved = true; main.removeCallbacks(longPress)
                        sendDownUpKeyEvents(if (dx > 0) KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT)
                        lastX = e.x
                    }
                }
                MotionEvent.ACTION_UP -> {
                    v.isPressed = false; main.removeCallbacks(longPress)
                    if (!moved && !longPressed) type(" ")
                }
                MotionEvent.ACTION_CANCEL -> { v.isPressed = false; main.removeCallbacks(longPress) }
            }
            true
        }
        return b
    }

    private fun deleteOne() {
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        if (buffer.isNotEmpty()) buffer.deleteCharAt(buffer.length - 1)
        updateSuggestions()
        scheduleAnalyze()
    }

    private fun doEnter() {
        val info = currentInputEditorInfo
        val action = (info?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val noAction = ((info?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            currentInputConnection?.performEditorAction(action)
        } else sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        if (!secure) buffer.append(" ")
        updateSuggestions()
    }

    private fun pasteClipboard() {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
        if (!t.isNullOrEmpty()) type(t)
    }

    private fun picker() = (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()

    // ---- long-press accents -------------------------------------------------
    private fun showAlts(anchor: View, chars: String) {
        altPopup?.dismiss()
        val box = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; background = shape(cSpecial); setPadding(dp(4), dp(4), dp(4), dp(4)) }
        val pop = PopupWindow(box, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, false)
        chars.forEach { c ->
            val out = if (shiftState != 0 && c.isLetter()) c.uppercaseChar().toString() else c.toString()
            box.addView(key(out) { type(out); pop.dismiss(); if (shiftState == 1) { shiftState = 0; refreshCase() } },
                LinearLayout.LayoutParams(dp(40), dp(46)).apply { setMargins(dp(2), 0, dp(2), 0) })
        }
        val loc = IntArray(2); anchor.getLocationInWindow(loc)
        pop.showAtLocation(anchor, Gravity.NO_GRAVITY, maxOf(0, loc[0] - dp(8)), loc[1] - dp(60))
        altPopup = pop
        main.postDelayed({ pop.dismiss() }, 4000)
    }

    // ---- word suggestions ---------------------------------------------------
    private fun updateSuggestions() {
        if (!::suggestBar.isInitialized || secure) return
        val before = currentInputConnection?.getTextBeforeCursor(24, 0)?.toString().orEmpty()
        val prefix = before.takeLastWhile { it.isLetter() }
        val matches = if (prefix.isEmpty()) emptyList()
        else words.filter { it.startsWith(prefix.lowercase()) && it != prefix.lowercase() }.take(3)
        suggestBar.removeAllViews()
        if (matches.isEmpty()) {
            emojiSet.forEach { e ->
                suggestBar.addView(key(e) { type(e) }.apply { textSize = 20f },
                    LinearLayout.LayoutParams(dp(52), dp(42)).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
            }
        } else {
            matches.forEach { w ->
                val shown = if (prefix.first().isUpperCase()) w.replaceFirstChar { it.uppercase() } else w
                suggestBar.addView(key(shown, true, size = 16f) { applySuggestion(shown, prefix.length) },
                    LinearLayout.LayoutParams(dp(110), dp(42)).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
            }
        }
    }

    private fun applySuggestion(word: String, prefixLen: Int) {
        currentInputConnection?.deleteSurroundingText(prefixLen, 0)
        currentInputConnection?.commitText("$word ", 1)
        repeat(prefixLen) { if (buffer.isNotEmpty()) buffer.deleteCharAt(buffer.length - 1) }
        buffer.append("$word ")
        updateSuggestions()
        scheduleAnalyze()
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        val t = info?.inputType ?: 0
        val cls = t and InputType.TYPE_MASK_CLASS
        val v = t and InputType.TYPE_MASK_VARIATION
        secure = (cls == InputType.TYPE_CLASS_TEXT && v in setOf(
            InputType.TYPE_TEXT_VARIATION_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
        )) || (cls == InputType.TYPE_CLASS_NUMBER && v == InputType.TYPE_NUMBER_VARIATION_PASSWORD)
        if (secure) { buffer.clear(); stopPlayer(); strip.text = "🔒 Off in password fields" } else updateSuggestions()
    }

    override fun onFinishInputView(finishingInput: Boolean) { super.onFinishInputView(finishingInput); altPopup?.dismiss(); stopPlayer() }
    override fun onDestroy() { stopPlayer(); super.onDestroy() }

    // ---- typing + AI judging -----------------------------------------------
    private fun type(s: String) {
        altPopup?.dismiss()
        currentInputConnection?.commitText(s, 1)
        if (secure) return
        buffer.append(s)
        if (buffer.length > 400) buffer.delete(0, buffer.length - 400)
        updateSuggestions()
        scheduleAnalyze(if (s.any { it.code > 0x2000 }) 150L else 1200L)   // emojis react almost instantly
    }

    private fun scheduleAnalyze(delayMs: Long = 1200L) {
        pending?.let { main.removeCallbacks(it) }
        pending = Runnable { analyze() }.also { main.postDelayed(it, delayMs) }
    }

    private fun analyze() {
        if (secure) return
        val fieldText = currentInputConnection?.getTextBeforeCursor(200, 0)?.toString().orEmpty()
        val m = MoodEngine.detect(buffer.toString().takeLast(250) + " " + fieldText) ?: return
        if (m != mood) { mood = m; songIdx = 0; choose(auto) }
    }

    private fun choose(play: Boolean) {
        val list = Trending.forMood(mood)
        val s = list[songIdx % list.size]
        song = s; link = null
        emojiSet = moodEmojis[mood] ?: emojiSet
        updateSuggestions()
        strip.text = "${mood?.emoji ?: "🔥"} ${mood?.label ?: "Trending"}  •  ${s.title} – ${s.artist}"
        if (play) fetchAndPlay(s)
    }

    // ---- music (30 s previews from the iTunes Search API, India store) -------
    private fun fetchAndPlay(s: Song) {
        val token = ++playToken
        stopPlayer()
        Thread {
            try {
                val term = URLEncoder.encode("${s.title} ${s.artist}", "UTF-8")
                val conn = URL("https://itunes.apple.com/search?media=music&entity=song&country=IN&limit=1&term=$term")
                    .openConnection() as HttpURLConnection
                conn.connectTimeout = 5000; conn.readTimeout = 5000
                val results = JSONObject(conn.inputStream.bufferedReader().readText()).getJSONArray("results")
                if (results.length() == 0) { main.post { if (token == playToken) strip.append("  (not found)") }; return@Thread }
                val o = results.getJSONObject(0)
                val preview = o.optString("previewUrl")
                val view = o.optString("trackViewUrl")
                main.post { if (token == playToken) { link = view; startPlayer(preview) } }
            } catch (e: Exception) {
                main.post { if (token == playToken) strip.append("  (offline)") }
            }
        }.start()
    }

    private fun startPlayer(url: String) {
        stopPlayer()
        player = MediaPlayer().apply {
            setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            setDataSource(url)
            setOnPreparedListener { it.start(); playBtn.text = "⏸" }
            setOnCompletionListener { playBtn.text = "▶" }
            prepareAsync()
        }
    }

    private fun stopPlayer() {
        player?.release(); player = null
        if (::playBtn.isInitialized) playBtn.text = "▶"
    }

    private fun togglePlay() {
        val p = player
        when {
            p == null -> song?.let { fetchAndPlay(it) } ?: choose(true)
            p.isPlaying -> { p.pause(); playBtn.text = "▶" }
            else -> { p.start(); playBtn.text = "⏸" }
        }
    }

    private fun sendClip() {
        val s = song ?: return
        val l = link ?: return
        currentInputConnection?.commitText("🎵 ${s.title} – ${s.artist} $l ", 1)
    }

    private fun openYouTube() {
        val s = song ?: return
        val q = Uri.encode("${s.title} ${s.artist}")
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$q"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ---- view helpers -------------------------------------------------------
    private fun shape(c: Int) = GradientDrawable().apply { cornerRadius = dp(9).toFloat(); setColor(c) }

    private fun darken(c: Int) = Color.rgb((Color.red(c) * 0.85).toInt(), (Color.green(c) * 0.85).toInt(), (Color.blue(c) * 0.85).toInt())

    private fun row() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }

    private fun weight(w: Float, h: Int = 46) =
        LinearLayout.LayoutParams(0, dp(h), w).apply { setMargins(dp(2), dp(3), dp(2), dp(3)) }

    /** One key. No vibration, no click sound. Long-press shows alternates if given. */
    private fun key(label: String, special: Boolean = false, accent: Boolean = false, size: Float = 17f,
                    alts: String? = null, onTap: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = size
        minWidth = 0; minimumWidth = 0; minHeight = 0; minimumHeight = 0
        setPadding(0, 0, 0, 0)
        stateListAnimator = null
        val base = if (accent) cAccent else if (special) cSpecial else cKey
        background = StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), shape(darken(base)))
            addState(intArrayOf(), shape(base))
        }
        setTextColor(if (accent) Color.WHITE else cText)
        isHapticFeedbackEnabled = false
        isSoundEffectsEnabled = false
        setOnClickListener { onTap() }
        if (alts != null) setOnLongClickListener { showAlts(this, alts); true }
    }
}
